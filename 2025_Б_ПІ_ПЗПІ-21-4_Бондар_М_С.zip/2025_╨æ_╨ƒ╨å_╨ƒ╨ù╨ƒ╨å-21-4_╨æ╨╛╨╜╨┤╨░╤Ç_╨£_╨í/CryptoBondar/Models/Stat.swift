//
//  Stat.swift
//  CryptoBondar
//
//  Created by Никита Бондарь on 14.09.2024.
//

import Foundation

struct Stat: Identifiable {
    
    let id = UUID()
    let title : String
    let value : String
    let percatageChenge : Double?
    
    init(title: String, value: String, percatageChenge: Double? = nil){
        self.title = title
        self.value = value
        self.percatageChenge = percatageChenge
    }
    
}


