//
//  CoinModel.swift
//  CryptoBondar
//
//  Created by Никита Бондарь on 11.09.2024.
//

import Foundation

class CoinModel{
    
}
