import Foundation
import SwiftUI

class LanguageManager: ObservableObject {
    @AppStorage("selectedLanguage") var selectedLanguage: String = Locale.preferredLanguages.first?.prefix(2).description ?? "en" {
        didSet {
            Bundle.setLanguage(selectedLanguage)
            objectWillChange.send()
        }
    }
    
    static let shared = LanguageManager()
}
