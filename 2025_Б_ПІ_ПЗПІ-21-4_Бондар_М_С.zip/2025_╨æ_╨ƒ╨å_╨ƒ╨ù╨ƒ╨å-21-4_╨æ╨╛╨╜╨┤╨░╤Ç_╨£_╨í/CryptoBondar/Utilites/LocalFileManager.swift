import Foundation
import SwiftUI


class LocalFileManager{
    
    static let instance = LocalFileManager()
    
    private init() { }
    
    func saveImage(img: UIImage, imgName: String, folderName: String) {
        
        createFolder(folderName: folderName)
        
        guard 
            let data = img.pngData(),
            let url = getUrlForImage(imgName: imgName, folderName: folderName)
        else {return}
        
        do{
            try data.write(to: url)
        } catch let err {
            print(err)
        }
    }
    
    
    func getImg(imgName: String, folderName: String) -> UIImage? {
        guard let url = getUrlForImage(imgName: imgName, folderName: folderName),
              FileManager.default.fileExists(atPath: url.path) else {
            return nil
        }
        return UIImage(contentsOfFile: url.path)
    }
    
    private func createFolder(folderName: String){
        guard let url = getUrlForFolder(name: folderName) else {return}
        if !FileManager.default.fileExists(atPath: url.path) {
            do {
                try FileManager.default.createDirectory(at: url, withIntermediateDirectories: true, attributes: nil)
            } catch let err {
                print(err)
            }
        }
    }
    
    private func getUrlForFolder(name: String) -> URL? {
        guard let url = FileManager.default.urls(for: .cachesDirectory, in: .userDomainMask)
            .first
        else{
            return nil
        }
        return url.appendingPathComponent(name)
    }
    
    private func getUrlForImage(imgName: String, folderName:String) -> URL? {
        guard let folderUrl = getUrlForFolder(name: folderName)
        else{
            return nil
        }
        return folderUrl.appendingPathComponent(imgName + ".png")
    }
}
