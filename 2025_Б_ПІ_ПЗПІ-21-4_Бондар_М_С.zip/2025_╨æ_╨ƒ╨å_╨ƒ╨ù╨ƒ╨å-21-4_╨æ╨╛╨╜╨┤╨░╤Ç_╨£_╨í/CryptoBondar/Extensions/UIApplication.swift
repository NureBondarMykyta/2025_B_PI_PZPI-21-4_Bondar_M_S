//
//  UIApplication.swift
//  CryptoBondar
//
//  Created by Никита Бондарь on 14.09.2024.
//

import Foundation
import SwiftUI


extension UIApplication{
    
}
