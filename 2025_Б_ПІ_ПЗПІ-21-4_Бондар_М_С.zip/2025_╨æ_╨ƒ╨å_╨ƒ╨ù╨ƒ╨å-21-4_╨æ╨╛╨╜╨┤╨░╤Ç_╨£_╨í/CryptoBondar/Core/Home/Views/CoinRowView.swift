//
//  CoinRowView.swift
//  CryptoBondar
//
//  Created by Никита Бондарь on 11.09.2024.
//

import SwiftUI

struct CoinRowView: View {
    
    let showHoldingColumn: Bool
    let coin : Coin
    
    var body: some View {
        HStack(spacing: 0){
            leftColumn
            Spacer()
            if showHoldingColumn{
                centerCoumn
            }
            rigthColumn
        }
        .font(.subheadline)
        .background(
            Color.theme.bgColor.opacity(0.001)
        )
    }
}


struct CoinRowView_Previews: PreviewProvider{
    static var previews: some View{
        CoinRowView(showHoldingColumn: true, coin: dev.coin)
    }
}


extension CoinRowView{
    private var leftColumn : some  View{
        HStack(spacing:0){
            Text("\(coin.rank)")
                .font(.caption)
                .foregroundColor(Color.theme.secondaryColor)
                .frame(minWidth: 30)
            CoinImageView(coin: coin)
                .frame(width: 30, height: 30)
            Text(coin.symbol.uppercased())
                .font(.headline)
                .padding(.leading, 6)
                .foregroundColor(Color.theme.accent)
        }
    }
    
    private var centerCoumn : some View{
        VStack(alignment: .trailing){
            Text(coin.currentHoldingsValue.asCurrencyWith2Decimals())
            Text((coin.currentHoldings ?? 0).asNumberString())
        }
        .foregroundColor(Color.theme.accent)
    }
    private var rigthColumn : some View{
        VStack(alignment: .trailing){
            Text(coin.currentPrice.asCurrencyWith2Decimals())
                .bold()
                .foregroundColor(Color.theme.accent)
            Text(coin.priceChangePercentage24H?.asPercentString() ?? "")
                .foregroundColor(
                    (coin.priceChangePercentage24H ?? 0) >= 0 ?
                    Color.theme.green :
                    Color.theme.red
                )
        }
        .frame(width: UIScreen.main.bounds.width / 3.5 , alignment: .trailing)
    }
}
