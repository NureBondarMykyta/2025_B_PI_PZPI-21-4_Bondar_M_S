import SwiftUI

struct HomeView: View {
    @EnvironmentObject private var vm : HomeViewModel
    @EnvironmentObject private var languageManager: LanguageManager

    @State private var showPortfolio: Bool = false
    @State private var showPortfolioView:  Bool = false
    @State private var showSettingsView : Bool = false
    @State private var selectedCoin : Coin? = nil
    @State private var showDetailView : Bool = false

    var body: some View {
        ZStack {
            Color.theme.bgColor
                .ignoresSafeArea()
                .sheet(isPresented: $showPortfolioView) {
                    NavigationView {
                        PortfolioView()
                            .environmentObject(vm)
                    }
                }

            VStack {
                homeHeader
                HomeStatView(showPortfolio: $showPortfolio)
                SearchBarView(searachText: $vm.searchText)
                columnTitles
                    .font(.caption)
                    .foregroundColor(Color.theme.secondaryColor)
                    .padding(.horizontal)

                if !showPortfolio {
                    allCoinsList
                        .transition(.move(edge: .leading))
                } else {
                    ZStack(alignment: .center) {
                        if vm.portfolioCoins.isEmpty && vm.searchText.isEmpty {
                            Text(NSLocalizedString("empty_portfolio_message", comment: ""))
                                .foregroundColor(Color.theme.secondaryColor)
                                .font(.callout)
                                .fontWeight(.medium)
                                .multilineTextAlignment(.center)
                                .padding(100)
                        } else {
                            portfolioCoinsList
                        }
                    }
                    .transition(.move(edge: .trailing))
                }

                Spacer()
            }
            .sheet(isPresented: $showSettingsView) {
                SettingsView()
                    .environmentObject(languageManager)
            }
        }
        .background(
            NavigationLink(
                destination: DetailLoadingView(coin: $selectedCoin),
                isActive: $showDetailView,
                label: {
                    EmptyView()
                })
        )
        .onChange(of: languageManager.selectedLanguage) { _ in
            vm.reloadData()
        }
    }
}

extension HomeView {
    private var homeHeader: some View {
        HStack {
            CircleButtonView(imageName: showPortfolio ? "plus" : "info")
                .animation(.none)
                .onTapGesture {
                    if showPortfolio {
                        showPortfolioView.toggle()
                    } else {
                        showSettingsView.toggle()
                    }
                }
                .background(
                    CircleButtonAnimationView(animate: $showPortfolio)
                )

            Spacer()

            Text(showPortfolio
                 ? NSLocalizedString("portfolio", comment: "")
                 : NSLocalizedString("live_prices", comment: ""))
                .font(.headline)
                .fontWeight(.heavy)
                .foregroundColor(Color.theme.accent)
                .animation(.none)

            Spacer()

            CircleButtonView(imageName: "chevron.right")
                .rotationEffect(Angle(degrees: showPortfolio ? 180 : 0))
                .onTapGesture {
                    withAnimation(.spring) {
                        showPortfolio.toggle()
                    }
                }
        }
        .padding(.horizontal)
    }

    private var allCoinsList: some View {
        List {
            ForEach(vm.allCoins) { coin in
                CoinRowView(showHoldingColumn: false, coin: coin)
                    .onTapGesture {
                        segue(coin: coin)
                    }
            }
        }
        .listStyle(PlainListStyle())
    }

    private var portfolioCoinsList: some View {
        List {
            ForEach(vm.portfolioCoins) { coin in
                CoinRowView(showHoldingColumn: true, coin: coin)
                    .onTapGesture {
                        segue(coin: coin)
                    }
            }
        }
        .listStyle(PlainListStyle())
    }

    private func segue(coin: Coin) {
        selectedCoin = coin
        showDetailView.toggle()
    }

    private var columnTitles: some View {
        HStack {
            HStack(spacing: 4) {
                Text(NSLocalizedString("coin", comment: ""))
                Image(systemName: "chevron.down")
                    .opacity((vm.sortOption == .rank || vm.sortOption == .rankReversed) ? 1.0 : 0.0)
                    .rotationEffect(Angle(degrees: vm.sortOption == .rank ? 0 : 180))
            }
            .onTapGesture {
                withAnimation(.default) {
                    vm.sortOption = (vm.sortOption == .rank) ? .rankReversed : .rank
                }
            }

            Spacer()

            if showPortfolio {
                HStack(spacing: 4) {
                    Text(NSLocalizedString("holdings", comment: ""))
                    Image(systemName: "chevron.down")
                        .opacity((vm.sortOption == .holdings || vm.sortOption == .holdingsReversed) ? 1.0 : 0.0)
                        .rotationEffect(Angle(degrees: vm.sortOption == .holdings ? 0 : 180))
                }
                .onTapGesture {
                    withAnimation(.default) {
                        vm.sortOption = (vm.sortOption == .holdings) ? .holdingsReversed : .holdings
                    }
                }
            }

            HStack(spacing: 4) {
                Text(NSLocalizedString("price", comment: ""))
                Image(systemName: "chevron.down")
                    .opacity((vm.sortOption == .price || vm.sortOption == .priceReversed) ? 1.0 : 0.0)
                    .rotationEffect(Angle(degrees: vm.sortOption == .price ? 0 : 180))
            }
            .frame(width: UIScreen.main.bounds.width / 3.5, alignment: .trailing)
            .onTapGesture {
                withAnimation(.default) {
                    vm.sortOption = (vm.sortOption == .price) ? .priceReversed : .price
                }
            }

            Button {
                withAnimation(.linear(duration: 2.0)) {
                    vm.reloadData()
                }
            } label: {
                Image(systemName: "goforward")
            }
            .rotationEffect(Angle(degrees: vm.isLoading ? 360 : 0))
        }
    }
}

