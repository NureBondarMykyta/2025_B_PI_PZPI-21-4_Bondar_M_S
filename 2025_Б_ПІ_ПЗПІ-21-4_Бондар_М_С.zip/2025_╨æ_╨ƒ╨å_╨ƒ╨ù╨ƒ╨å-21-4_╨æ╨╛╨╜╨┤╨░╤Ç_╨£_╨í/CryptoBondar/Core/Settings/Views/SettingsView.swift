import SwiftUI

struct SettingsView: View {
    @Environment(\.dismiss) var dismiss
    @EnvironmentObject var languageManager: LanguageManager
    @State private var showLanguageSheet = false

    let coingeckoURL = URL(string: "https://www.coingecko.com")!

    var body: some View {
        NavigationView {
            List {
                Section(header: Text(NSLocalizedString("nure", comment: ""))) {
                    VStack(alignment: .leading) {
                        Image("logo")
                            .resizable()
                            .frame(width: 100, height: 100)
                            .clipShape(RoundedRectangle(cornerRadius: 20))
                        Text(NSLocalizedString("app_description", comment: ""))
                            .font(.callout)
                            .fontWeight(.medium)
                            .foregroundColor(Color.theme.accent)
                    }
                    .padding()
                }

                Section(header: Text(NSLocalizedString("coin_gecko", comment: ""))) {
                    VStack(alignment: .leading) {
                        Image("coingecko")
                            .resizable()
                            .scaledToFit()
                            .frame(height: 100)
                            .clipShape(RoundedRectangle(cornerRadius: 20))
                        Text(NSLocalizedString("coingecko_description", comment: ""))
                            .font(.callout)
                            .fontWeight(.medium)
                            .foregroundColor(Color.theme.accent)
                    }
                    .padding()
                    Link(NSLocalizedString("coingecko_website", comment: ""), destination: coingeckoURL)
                }

                Section {
                    Button {
                        showLanguageSheet = true
                    } label: {
                        Text(NSLocalizedString("language_button", comment: ""))
                            .foregroundColor(.blue)
                    }
                }
            }
            .listStyle(GroupedListStyle())
            .navigationTitle(NSLocalizedString("settings_title", comment: ""))
            .toolbar {
                ToolbarItem(placement: .navigationBarLeading) {
                    Button {
                        dismiss()
                    } label: {
                        Image(systemName: "xmark")
                            .foregroundColor(.red)
                            .font(.headline)
                    }
                }
            }
            .confirmationDialog(NSLocalizedString("language_button", comment: ""), isPresented: $showLanguageSheet) {
                Button(NSLocalizedString("english", comment: "")) {
                    languageManager.selectedLanguage = "en"
                }
                Button(NSLocalizedString("ukrainian", comment: "")) {
                    languageManager.selectedLanguage = "uk"
                }
            }
        }
    }
}

#Preview {
    SettingsView()
        .environmentObject(LanguageManager.shared)
}
