import Foundation
import Combine

class DetailViewModel: ObservableObject {
    
    @Published var overviewStatistics: [Stat] = []
    @Published var additionalStatistics: [Stat] = []
    @Published var coinDescription: String? = nil
    @Published var websiteURL: String? = nil
    @Published var redditURL: String? = nil
    
    @Published var coin: Coin
    private let coinDetailService: CoinDetailDataService
    private var cancellables: Set<AnyCancellable> = Set<AnyCancellable>()
    
    init(coin: Coin) {
        self.coin = coin
        self.coinDetailService = CoinDetailDataService(coin: coin)
        self.addSubscribers()
    }
    
    private func addSubscribers() {
        coinDetailService.$coinDetails
            .combineLatest($coin)
            .map(mapDataToStatistics)
            .sink { [weak self] (returnedArrays) in
                self?.overviewStatistics = returnedArrays.overview
                self?.additionalStatistics = returnedArrays.additional
            }
            .store(in: &cancellables)
        
        coinDetailService.$coinDetails
            .sink { [weak self] (returnedCoinDetails) in
                self?.coinDescription = returnedCoinDetails?.readableDescription
                self?.websiteURL = returnedCoinDetails?.links?.homepage?.first
                self?.redditURL = returnedCoinDetails?.links?.subredditURL
            }
            .store(in: &cancellables)
    }
    
    private func mapDataToStatistics(coinDetailModel: CoinDetailModel?, coinModel: Coin) -> (overview: [Stat], additional: [Stat]) {
        let price = coinModel.currentPrice.asCurrencyWith2Decimals()
        let pricePercentChange = coinModel.priceChangePercentage24H
        let priceStat = Stat(
            title: NSLocalizedString("current_price", comment: ""),
            value: price,
            percatageChenge: pricePercentChange
        )
        
        let marketCap = "$" + (coinModel.marketCap?.formattedWithAbbreviations() ?? "")
        let marketCapPercentChange = coinModel.marketCapChangePercentage24H
        let marketCapStat = Stat(
            title: NSLocalizedString("market_cap", comment: ""),
            value: marketCap,
            percatageChenge: marketCapPercentChange
        )
        
        let rank = "\(coinModel.rank)"
        let rankStat = Stat(
            title: NSLocalizedString("rank", comment: ""),
            value: rank
        )
        
        let volume = "$" + (coinModel.totalVolume?.formattedWithAbbreviations() ?? "")
        let volumeStat = Stat(
            title: NSLocalizedString("volume", comment: ""),
            value: volume
        )
        
        let overviewArray: [Stat] = [priceStat, marketCapStat, rankStat, volumeStat]
        
        let high = coinModel.high24H?.asCurrencyWith2Decimals() ?? "n/a"
        let highStat = Stat(
            title: NSLocalizedString("high_24h", comment: ""),
            value: high
        )
        
        let low = coinModel.low24H?.asCurrencyWith2Decimals() ?? "n/a"
        let lowStat = Stat(
            title: NSLocalizedString("low_24h", comment: ""),
            value: low
        )
        
        let priceChange = coinModel.priceChange24H?.asCurrencyWith2Decimals() ?? "n/a"
        let pricePercentChange2 = coinModel.priceChangePercentage24H
        let priceChangeStat = Stat(
            title: NSLocalizedString("price_change_24h", comment: ""),
            value: priceChange,
            percatageChenge: pricePercentChange2
        )
        
        let marketCapChange = "$" + (coinModel.marketCapChange24H?.formattedWithAbbreviations() ?? "n/a")
        let marketCapPercentChange2 = coinModel.marketCapChangePercentage24H
        let marketCapChangeStat = Stat(
            title: NSLocalizedString("market_cap_change_24h", comment: ""),
            value: marketCapChange,
            percatageChenge: marketCapPercentChange2
        )
        
        let blockTime = coinDetailModel?.blockTimeInMinutes ?? 0
        let blockTimeString = blockTime == 0 ? "n/a" : "\(blockTime)"
        let blockTimeStat = Stat(
            title: NSLocalizedString("block_time", comment: ""),
            value: blockTimeString
        )
        
        let hashing = coinDetailModel?.hashingAlgorithm ?? "n/a"
        let hashingStat = Stat(
            title: NSLocalizedString("hashing_algorithm", comment: ""),
            value: hashing
        )
        
        let additionalArray: [Stat] = [
            highStat,
            lowStat,
            priceChangeStat,
            marketCapChangeStat,
            blockTimeStat,
            hashingStat
        ]
        
        return (overviewArray, additionalArray)
    }
}
