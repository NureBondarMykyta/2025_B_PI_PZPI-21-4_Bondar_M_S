import SwiftUI

struct CancelButtonView: View {
    
    @Environment(\.dismiss) var dismiss
    
    var body: some View {
        Button(action: {
            dismiss()
        }, label: {
            Image(systemName: "xmark")
                .foregroundColor(Color.red)
                .font(.headline)
        })

    }
}

#Preview {
    CancelButtonView()
}
