import SwiftUI

struct StatView: View {
    let stat: Stat
    var body: some View {
        VStack(alignment: .leading, spacing: 4){
            Text(stat.title)
                .font(.caption)
                .foregroundColor(Color.theme.secondaryColor)
            Text(stat.value)
                .font(.headline)
                .foregroundColor(Color.theme.accent)
            HStack(spacing: 2) {
                if ((stat.percatageChenge ?? 0) >= 0){
                    Image(systemName: "arrowtriangle.up.fill")
                        .foregroundColor(Color.theme.green)
                    Text(stat.percatageChenge?.asPercentString() ?? "")
                        .foregroundColor(Color.theme.green)
                } else {
                    Image(systemName: "arrowtriangle.down.fill")
                        .foregroundColor(Color.theme.red)
                    Text(stat.percatageChenge?.asPercentString() ?? "")
                        .foregroundColor(Color.theme.red)
                }
            }
            .opacity(stat.percatageChenge == nil ? 0 : 1)
            .font(.caption)
            .bold()
        }
    }
}

struct StatView_Previews: PreviewProvider{
    static var previews: some View{
            StatView(stat: dev.stat1)
            StatView(stat: dev.stat2)
            StatView(stat: dev.stat3)
            
    }
}
