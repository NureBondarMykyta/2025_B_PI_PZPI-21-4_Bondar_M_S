import SwiftUI

struct SearchBarView: View {
    @Binding var searachText: String
    @EnvironmentObject var languageManager: LanguageManager
    
    var body: some View {
        HStack {
            Image(systemName: "magnifyingglass")
                .foregroundColor(Color.theme.secondaryColor)
                .padding()
            
            TextField(
                NSLocalizedString("search_placeholder", comment: ""),
                text: $searachText
            )
            .foregroundColor(Color.theme.accent)
            .disableAutocorrection(true)
            
            Image(systemName: "xmark")
                .offset(x: -5)
                .padding()
                .foregroundColor(Color.theme.red.opacity(0.7))
                .opacity(searachText.isEmpty ? 0 : 1)
                .onTapGesture {
                    searachText = ""
                }
        }
        .font(.headline)
        .background(
            RoundedRectangle(cornerRadius: 25.0)
                .fill(Color.theme.bgColor)
                .shadow(
                    color: Color.theme.accent.opacity(0.25),
                    radius: 10
                )
        )
        .padding()
    }
}
