//
//  CircleButtonView.swift
//  CryptoBondar
//
//  Created by Никита Бондарь on 11.09.2024.
//

import SwiftUI

struct CircleButtonView: View {
    
    let imageName: String
    
    var body: some View {
       Image(systemName: imageName)
            .font(.headline)
            .foregroundColor(Color.theme.accent)
            .frame(width: 50, height: 50)
            .background(
                Circle()
                    .foregroundColor(Color.theme.bgColor)
            )
            .shadow(color: Color.theme.accent.opacity(0.3), radius: 10)
            .padding()
    }
}

#Preview {
    Group{
        CircleButtonView(imageName: "heart.fill")
        CircleButtonView(imageName: "plus")
            .colorScheme(.dark)
    }
}
