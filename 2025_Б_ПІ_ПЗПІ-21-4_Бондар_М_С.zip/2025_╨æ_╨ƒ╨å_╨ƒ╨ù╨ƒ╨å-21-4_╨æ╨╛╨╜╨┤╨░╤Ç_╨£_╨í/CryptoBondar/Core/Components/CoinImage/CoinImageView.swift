//
//  CoinImageView.swift
//  CryptoBondar
//
//  Created by Никита Бондарь on 12.09.2024.
//

import SwiftUI





struct CoinImageView: View {
    
    @StateObject var vm : CoinImageViewModel
    
    
    init(coin: Coin){
        _vm = StateObject(wrappedValue: CoinImageViewModel(coin: coin))
    }
    
    var body: some View {
        ZStack{
            if let image = vm.image{
                Image(uiImage: image)
                    .resizable()
                    .scaledToFit()
            } else if vm.isLoading{
                Circle()
                    .frame(width: 30, height: 30)
            } else {
                Image(systemName: "clock")
                    .foregroundColor(Color.theme.secondaryColor)
            }
        }
    }
}

struct CoinImageView_Previews: PreviewProvider{
    static var previews: some View{
        CoinImageView(coin: dev.coin)
    }
}
