import Foundation
import Combine


class MarketDataService {
    
    @Published var marketData : MarketData? = nil
    
    var marketDataSubscription : AnyCancellable?

    init() {
        getMarketData()
    }
    
    func getMarketData() {
        guard let url = URL(string: "https://api.coingecko.com/api/v3/global") else { return }
        
        marketDataSubscription = NetworkinManager.download(url: url)
            .decode(type: GlobalMarketData.self, decoder: JSONDecoder())
            
            .sink(receiveCompletion: NetworkinManager.handleCompletion, receiveValue: { [weak self] (returnedMarketData) in
                self?.marketData = returnedMarketData.data
                self?.marketDataSubscription?.cancel()
            })
    }
}
