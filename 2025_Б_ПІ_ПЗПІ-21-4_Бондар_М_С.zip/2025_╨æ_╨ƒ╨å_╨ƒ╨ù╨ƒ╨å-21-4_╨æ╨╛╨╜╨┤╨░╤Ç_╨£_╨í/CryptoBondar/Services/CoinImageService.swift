//
//  CoinImageService.swift
//  CryptoBondar
//
//  Created by Никита Бондарь on 12.09.2024.
//

import Foundation
import SwiftUI
import Combine


class CoinImageService{
    
    @Published var image : UIImage? = nil
    
    private var imageSubscription: AnyCancellable?
    private let fileManager = LocalFileManager.instance
    private let coin : Coin
    private let folderName = "coin_images"
    private let imgName : String
    
    init(coin:Coin){
        self.coin = coin
        self.imgName = coin.id
        getCoinImage()
    }
    
    private func getCoinImage(){
        if let savedImage = fileManager.getImg(imgName: imgName, folderName: folderName){
            image = savedImage
        } else {
            downloadCoinImage()
        }
    }
    
    private func downloadCoinImage(){
        guard let url = URL(string: coin.image) else { return }
        
        imageSubscription = NetworkinManager.download(url: url)
            .tryMap({ (data) -> UIImage? in
                return UIImage(data: data)
            })
            
            .sink(receiveCompletion: NetworkinManager.handleCompletion, receiveValue: { [weak self] (returnedImage) in
                guard let self = self, let downloadedImage = returnedImage  else { return }
                self.image = returnedImage
                self.imageSubscription?.cancel()
                self.fileManager.saveImage(img: downloadedImage, imgName: self.imgName, folderName: self.folderName)
            } )
    }
}
